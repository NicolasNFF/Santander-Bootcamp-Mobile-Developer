package one.digitalinnovation.digionebank

interface Depositavel {
    fun deposito(valor: Double)
}