package one.digitalinnovation.digionebank

interface Logavel {
    fun login(): Boolean
}