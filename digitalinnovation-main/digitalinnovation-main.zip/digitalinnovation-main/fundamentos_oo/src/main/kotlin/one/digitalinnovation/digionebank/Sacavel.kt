package one.digitalinnovation.digionebank

interface Sacavel {
    fun saque(valor: Double)
}